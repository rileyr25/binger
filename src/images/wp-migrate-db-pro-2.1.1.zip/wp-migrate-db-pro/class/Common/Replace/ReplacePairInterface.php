<?php

namespace DeliciousBrains\WPMDB\Common\Replace;

/**
 * Interface ReplacePairInterface
 *
 * @package DeliciousBrains\WPMDB\Common\Replace
 */
interface ReplacePairInterface {
    public function apply($subject);
}
